import java.util.ArrayList;
import java.util.List;

public class BerkeleyAgoritmo {
    public static void main(String[] args) {
        // Criação de alguns relógios fictícios
        Relogio relogio1 = new Relogio(10);
        Relogio relogio2 = new Relogio(15);
        Relogio relogio3 = new Relogio(20);

        System.out.println(relogio1);
        
        Relogio relogio4 = new Relogio(19);

        // Adiciona os relógios à lista
        List<Relogio> relogios = new ArrayList<>();
        relogios.add(relogio1);
        relogios.add(relogio2);
        relogios.add(relogio3);

        // Cria o servidor Berkeley
        ServerBerkeley servidor = new ServerBerkeley(relogios);

        // Sincroniza os relógios
        servidor.sincronizarRelogios();

        // Exibe os tempos após a sincronização
        for (Relogio relogio : relogios) {
            System.out.println("Tempo do Relógio: " + relogio.getTempo());
        }
    }
}
