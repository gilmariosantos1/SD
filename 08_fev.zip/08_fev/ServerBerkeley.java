import java.util.ArrayList;
import java.util.List;


class ServerBerkeley {
    private List<Relogio> relogios;

    public ServerBerkeley(List<Relogio> relogios) {
        this.relogios = relogios;
    }

    public void sincronizarRelogios() {
        int somaTempos = 0;

        // Calcula a soma dos tempos dos relógios dos clientes
        for (Relogio relogio : relogios) {
            somaTempos += relogio.getTempo();
        }

        // Calcula a média dos tempos
        int media = somaTempos / relogios.size();

        // Atualiza os relógios dos clientes com base na média
        for (Relogio relogio : relogios) {
            relogio.setTempo(relogio.getTempo() + (media - relogio.getTempo()));
        }
    }
}